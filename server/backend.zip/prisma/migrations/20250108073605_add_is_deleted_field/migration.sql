-- AlterTable
ALTER TABLE "chat_groups" ADD COLUMN     "isDelete" BOOLEAN NOT NULL DEFAULT false;
